/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.testproject;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

/**
 *
 * @author Jay Kamlesh Dave
 */
public class Testproject {
    //matrix multiplication...

    static int MatrixChainOrder1(int p[], int n) {
        /* For simplicity of the program, one extra row and one extra column are allocated in m[][]. 0th row and 0th column of m[][] are not used */
        int C[][] = new int[n][n];
        int K[][] = new int[n][n];
        int i, j, k, L, q;
        //Initialize...
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                C[i][j] = 0;
                K[i][j] = 0;
            }
        }
        // L is chain length.
        for (L = 2; L < n; L++) {
            for (i = 1; i < n - L + 1; i++) {
                j = i + L - 1;
                if (j == n) {
                    continue;
                }
                C[i][j] = Integer.MAX_VALUE;
                for (k = i; k <= j - 1; k++) {
                    // q = cost/scalar multiplications
                    q = C[i][k] + C[k + 1][j] + (p[i - 1] * p[k] * p[j]);
                    if (q < C[i][j]) {
                        C[i][j] = q;
                        K[i][j] = k;
                    }
                }
            }
        }
        System.out.println("-------C-------");
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                System.out.print(C[i][j] + "\t");
            }
            System.out.println("");
        }
        System.out.println("-------K-------");
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                System.out.print(K[i][j] + "\t");
            }
            System.out.println("");
        }
        return C[1][n - 1];
    }

    public static void main(String args[]) {
        int n = 5;
        int[] p = {13, 5, 89, 3, 34};
        MatrixChainOrder1(p, n);
    }
}
