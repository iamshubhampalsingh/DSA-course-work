/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.testproject3;

import java.util.*;

/**
 *
 * @author Jay Kamlesh Dave
 */
public class Testproject3 {

    public static void main(String[] args) {
        //Making change Dynamic Programming...
        int c[][] = new int[4][13];
        int d[] = {1, 2, 6, 8};
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                c[i][j] = 0;
            }
        }

        for (int j = 0; j < 13; j++) {
            c[0][j] = j;
        }

        for (int i = 1; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                if (j - d[i] >= 0) {
                    c[i][j] = c[i - 1][j] < 1 + c[i][j - d[i]] ? c[i - 1][j] : 1 + c[i][j - d[i]];
                } else {
                    c[i][j] = c[i - 1][j];
                }
            }
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                System.out.print(c[i][j] + "\t");
            }
            System.out.println("");
        }
    }
}
