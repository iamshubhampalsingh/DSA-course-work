/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.testproject2;

import java.util.*;

/**
 *
 * @author Jay Kamlesh Dave
 */
public class Testproject2 {

    public static void main(String[] args) {
        //Knapsack Dynamic Programming       
        int p[] = {1, 6, 18, 22, 28};
        int w[] = {1, 2, 5, 6, 7};
        int m = 11;
        int PF[][] = new int[p.length][m + 1];
        for (int j = 0; j < m + 1; j++) {
            PF[0][j] = 1;
        }
        for (int i = 0; i < p.length; i++) {
            PF[i][0] = 0;
        }
        for (int i = 1; i < p.length; i++) {
            for (int j = 1; j < m + 1; j++) {
                if (j - w[i] >= 0) {
                    PF[i][j] = (PF[i - 1][j] > PF[i - 1][j - w[i]] + p[i]) ? PF[i - 1][j] : PF[i - 1][j - w[i]] + p[i];
                } else {
                    PF[i][j] = PF[i - 1][j];
                }
            }
        }
        for (int i = 0; i < p.length; i++) {
            for (int j = 0; j < m + 1; j++) {
                System.out.print(PF[i][j] + "\t");
            }
            System.out.println("");
        }
    }
}
