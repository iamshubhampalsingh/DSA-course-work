/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.testproject4;

import java.util.*;

/**
 *
 * @author Jay Kamlesh Dave
 */
public class Testproject4 {

    static void Mergesort(int arr[], int beg, int end) {
        System.out.println("--------------------");
        System.out.println("Mergesort(arr," + beg + "," + end + ")");
        if (beg < end) {
            // Find the middle point
            int mid = beg + (end - beg) / 2;
            System.out.println("MID=" + mid);
            // Sort first and second halves
            Mergesort(arr, beg, mid);
            Mergesort(arr, mid + 1, end);
            // Merge the sorted halves
            merge(arr, beg, mid, end);
        }
    }

    static void merge(int arr[], int beg, int mid, int end) {
        System.out.println("--------------------");
        System.out.println("--------------------");
        System.out.println("Merge(arr," + beg + "," + mid + "," + end + ")");
        // Find sizes of two subarrays to be merged
        int n1 = mid - beg + 1;
        int n2 = end - mid;
        // Create temp arrays
        int LeftArray[] = new int[n1];
        int RightArray[] = new int[n2];
        // Copy data to temp arrays
        for (int i = 0; i < n1; ++i) {
            LeftArray[i] = arr[beg + i];
        }
        for (int j = 0; j < n2; ++j) {
            RightArray[j] = arr[mid + 1 + j];
        }
//        printarr(LeftArray);
//        printarr(RightArray);
        // Merge the temp arrays
        // Initial indices of first and second subarrays
        int i = 0, j = 0;
        // Initial index of merged subarray array
        int k = beg;
        while (i < n1 && j < n2) {
            if (LeftArray[i] <= RightArray[j]) {
                arr[k] = LeftArray[i];
                i++;
            } else {
                arr[k] = RightArray[j];
                j++;
            }
            k++;
        }
        // Copy remaining elements of LeftArray[] if any
        while (i < n1) {
            arr[k] = LeftArray[i];
            i++;
            k++;
        }
        // Copy remaining elements of RightArray[] if any
        while (j < n2) {
            arr[k] = RightArray[j];
            j++;
            k++;
        }
        printarr(arr);
    }

    static void printarr(int a[]) {
        System.out.println("");
        for (int i = 0; i < a.length; i++) {
            System.out.print(i + "\t");
        }
        System.out.println("");
        for (int element : a) {
            System.out.print(element + "\t");
        }
        System.out.println("");
    }

    public static void main(String[] args) {
        int[] a = {12, 15, 11, 17, 19, 112, 111, 110};//{11, 12, 15, 17, 19, 110, 111, 112};
        printarr(a);
        quickSort(a, 0, a.length - 1);
        //Mergesort(a, 0, a.length - 1);
        printarr(a);
    }

    static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    static int partition(int[] arr, int low, int high) {
        System.out.println("-------------------------");
        System.out.println("partition(arr," + low + "," + high + ")");
        // Choosing the pivot
        int pivot = arr[high];
        System.out.println("Pivot:" + pivot);
        // Index of smaller element and indicates the right position of pivot found so far
        int i = (low - 1);
        for (int j = low; j <= high - 1; j++) {
            // If current element is smaller than the pivot
            if (arr[j] < pivot) {
                // Increment index of smaller element
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        printarr(arr);
        return (i + 1);
    }

    static void quickSort(int[] arr, int low, int high) {
        System.out.println("-------------------------");
        System.out.println("-------------------------");
        System.out.println("Quicksort(arr," + low + "," + high + ")");
        if (low < high) {
            // pi is partitioning index, arr[p] is now at right place
            int pi = partition(arr, low, high);
            System.out.println("Partition:" + pi);
            // Separately sort elements before partition and after partition
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }
}
